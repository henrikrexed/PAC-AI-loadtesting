# AI-Performance-Testing — `workload-model` (SCOPE)

Turn production **observability** into a realistic, reviewable **load-test workload model**.
Point it at a `(service, timeframe, environment)` and it auto-discovers the front-end,
reconstructs **behavioral user journeys** from the trace span-tree, caps them to **1–6 named
scenarios**, derives **load + ramp** (Little's Law from the *server* span, not the load-driver
wrapper), sizes **cache profiles**, and self-validates against a machine gate (**G0**) before any
human sees it. Output: a schema-valid `workload-model.json` + a `scenario-proposal.md`.

This is the **SCOPE** stage of the AI-driven load-testing methodology (ISI-5622 §3.1). It is
delivered in **three interchangeable packagings over one shared engine**:

| packaging | where | how you run it |
|---|---|---|
| **Claude skill** | [`claude-skill/SKILL.md`](claude-skill/SKILL.md) | an agent follows the skill; calls `engine/` |
| **Goose recipe** | [`goose-recipe/workload-model.yaml`](goose-recipe/workload-model.yaml) | `goose run --recipe goose-recipe/workload-model.yaml` |
| **CrewAI crew** | [`crewai/workload_model_crew.py`](crewai/workload_model_crew.py) | `python crewai/workload_model_crew.py` |

## One engine, three front-ends

```
backend (Dynatrace/dtctl, …)                         your load tool (k6, JMeter, …)
      │  input adapter (engine/dql_pack.md)                   ▲  renderer (downstream)
      ▼                                                       │
  neutral telemetry extract ──►  engine/  (agnostic)  ──►  workload-model.json  (+ proposal, G0-gated)
                                 clustering · archetypes · shaping · emit · g0_gate
```

The [`engine/`](engine/) package is backend- **and** tool-agnostic: pure `telemetry-in →
model-out`, no Dynatrace or k6 dependency. All three packagings invoke the same code via
`python -m engine.cli --extract <extract.json> --out <dir>`. 37 unit/gate tests
(`cd engine && python -m pytest tests/`).

## The behavioral split is the same engine across domains

A *journey* is a multi-step business flow, not a single span. Scenarios are grouped by **business
outcome** via `engine.archetypes.classify_by_terminal` — "did the flow reach a terminal action?":

| app | terminal signal | scenario A | scenario B |
|---|---|---|---|
| **otel-demo** (e-commerce) | reaches `payment`/`checkout` | **Buyer** (places an order) | **Browser** (search/browse) |
| **CrewAI + DeepSeek** (agentic) | reaches `execute_tool` | **Agentic** (tool-using ReAct turn) | **Conversational** (pure-LLM turn) |

See [`examples/`](examples/) for the real emitted models and
[`examples/GENERALIZATION.md`](examples/GENERALIZATION.md) for the validation: run live against a
CrewAI + DeepSeek agent, the skill recovered the two scenarios **and** their true weights
(31.9% agentic — matching the driver's configured 30% tool mix) with zero code changes.

## Gates & guarantees (G0, §3.1 exit criteria)

Emission is refused unless all hold: schema-valid · coverage ≥ 0.80 · 1–6 journeys · every step
`codeRef`/`unlinked` · server-span baselines · Little's-Law ratio ∈ [0.5, 2.0] · `correlates` for
every `dependsOn` · `cacheProfile` key-cardinality when `targetHitRatio > 0` · caps declared ·
DQL run live · **access-log availability confirmed OR a spans-only caveat recorded** · per-journey
evidence tags. Residual caveats R1 (sampling), R2 (mean ≠ peak), R5 (instrumentation coverage) are
rendered into every proposal.

## Quick start

```bash
cd engine && python -m pytest tests/          # 37 passing
# run the engine on a captured neutral extract:
python -m engine.cli --extract examples/crewai-deepseek-agent/extract.json --out /tmp/out
```

## Layout

```
engine/        shared agnostic core: clustering · archetypes · shaping · emit · g0_gate · schema.json · cli.py · dql_pack.md · tests/
claude-skill/  SKILL.md (Claude skill packaging)
goose-recipe/  workload-model.yaml (Goose recipe packaging)
crewai/        workload_model_crew.py (CrewAI packaging)
examples/      worked outputs: otel-astronomy-frontend (commerce) + crewai-deepseek-agent (agentic) + GENERALIZATION.md
```
