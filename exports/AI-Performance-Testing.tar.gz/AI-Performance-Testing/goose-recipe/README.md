# Goose recipe — workload-model (SCOPE)

Run it:
```bash
goose run --recipe goose-recipe/workload-model.yaml \
  --params timeframe=-3h environment=oat05854 terminal_signal=auto
```
The recipe drives the SCOPE workflow with the builtin `developer` extension (shell + files): it
runs the dtctl/DQL pack (`engine/dql_pack.md`), assembles a neutral extract, then calls
`python3 -m engine.cli` to emit a G0-gated `workload-model.json` + `scenario-proposal.md`.
Leave `service` blank to auto-discover the front-end. See the repo README for the full picture.
