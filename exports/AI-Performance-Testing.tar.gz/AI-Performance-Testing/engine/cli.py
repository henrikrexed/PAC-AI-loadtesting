"""Shared CLI for the workload-model engine — the single entry point all three packagings
(Claude skill, Goose recipe, CrewAI crew) invoke.

    python -m engine.cli --extract <extract.json> --out <dir> [--mode agentic|commerce]

Input: a **neutral telemetry extract** (JSON) produced by a backend adapter (the dtctl/DQL pack
in `dql_pack.md`, or any other backend). Output: `<dir>/workload-model.json` +
`<dir>/scenario-proposal.md`, self-validated by the G0 gate. Exit 0 iff G0 passes.

The engine is backend- and tool-agnostic: it never talks to Dynatrace or k6. It turns neutral
facts into a workload model and gates it. Commerce (Buyer/Browser) and agentic apps
(Agentic/Conversational) are the same engine with a different terminal-action signal.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import shaping as sh
from archetypes import AGENTIC_TOOL_PATTERNS, ORDER_TERMINAL_PATTERNS, classify_by_terminal
from clustering import Journey
from emit import build_model, render_proposal
from g0_gate import evaluate_g0


def _bl(d: dict) -> dict:
    return {"p50Ms": d["p50_ms"], "p95Ms": d["p95_ms"], "p99Ms": d["p99_ms"],
            "errorRate": d.get("errorRate", 0.0)}


def run(extract: dict, out_dir: Path, mode: str = "agentic") -> int:
    out_dir.mkdir(parents=True, exist_ok=True)

    if mode == "agentic":
        model, proposal = _build_agentic(extract)
    else:
        raise SystemExit("commerce mode: see engine/examples_build or the Claude skill; the "
                         "agentic path is the CLI reference. Both use the same engine functions.")

    (out_dir / "workload-model.json").write_text(json.dumps(model, indent=2) + "\n")
    (out_dir / "scenario-proposal.md").write_text(proposal)
    g = evaluate_g0(model, dql_run_live=True, proposal_text=proposal)
    print(json.dumps(g.to_dict(), indent=2))
    print(f"\nG0 {'PASS' if g.passed else 'FAIL'} ({sum(c.passed for c in g.checks)}/{len(g.checks)})  "
          f"-> {out_dir}/workload-model.json")
    return 0 if g.passed else 1


def _build_agentic(fx: dict):
    split = fx["archetype_split"]
    bl = fx["turn_baseline_agent_turn"]
    cr = fx.get("code_refs", {})
    entry_op = fx["front_end"]["resolved_op"]

    def journey(aid, name, weight, baseline, flow, payload_ref):
        return {
            "id": aid, "description": f"{name}. Reconstructed flow: {flow}",
            "weight": round(weight, 4), "entrypoint": entry_op,
            "codeRef": cr.get("entry_handler"), "evidenceSource": "span",
            "steps": [
                {"id": "s1", "service": fx["service"], "operation": "POST /request",
                 "callType": "http", "codeRef": cr.get("entry_handler"),
                 "evidenceSource": "span", "payloadRef": payload_ref},
                {"id": "s2", "service": fx["service"], "operation": "llm.call",
                 "callType": "http", "codeRef": cr.get("llm_call"), "evidenceSource": "span"},
            ],
            "baseline": _bl(baseline),
        }

    journeys = [
        journey("conversational", "Conversational — pure-LLM turn (no tool)",
                split["conversational_weight"], bl["conversational"],
                fx["span_trees"]["conversational"], "prompt_chat"),
        journey("agentic", "Agentic — tool-using ReAct turn (reaches execute_tool)",
                split["agentic_weight"], bl["agentic"],
                fx["span_trees"]["agentic"], "prompt_agentic"),
    ]
    # engine proves the split is structural (not hardcoded): classify the member ops too
    _demo = classify_by_terminal(
        [Journey(op="agentic.turn", traces=split["agentic_traces"],
                 svc_set={fx["service"], "execute_tool"}),
         Journey(op="chat.turn", traces=split["conversational_traces"], svc_set={fx["service"]})],
        patterns=AGENTIC_TOOL_PATTERNS,
        present=("agentic", "Agentic"), absent=("conversational", "Conversational"))
    assert {a.id for a in _demo} == {"agentic", "conversational"}

    stages, _cov = sh.shape_ramp(fx["per_minute_cov"]["interior_counts"])
    arr = fx["arrival"]
    llc = sh.littles_law(arr["arrival_rate_tps"], arr["mean_server_response_ms"],
                         arr["observed_concurrency"])

    model = build_model(
        name=fx["service"], target_service=fx["service"], environment=fx["environment"],
        generated_at=fx.get("generated_at", "1970-01-01T00:00:00Z"),
        timeframe=fx["timeframe"], timeframe_notes="agentic app; terminal signal = execute_tool",
        queries=["see engine/dql_pack.md — adapter ran these live"],
        access_log_availability=fx["access_log_availability"],
        sampling_ratio=fx["sampling_ratio"], arrival_model="open",
        stages=[vars(s) for s in stages], littles_law=vars(llc),
        journeys=journeys,
        payloads={
            "prompt_agentic": {"fields": [{"name": "task", "type": "string",
                "generator": "const", "values": ["use a tool to answer"], "distribution": "uniform"}], "seed": 42},
            "prompt_chat": {"fields": [{"name": "task", "type": "string",
                "generator": "const", "values": ["answer from knowledge"], "distribution": "uniform"}], "seed": 42},
        },
        caps={"maxRps": 2, "maxVus": 20, "maxDuration": "30m"},
        coverage=split["coverage"],
    )
    proposal = render_proposal(
        model, exclusions="none within service scope",
        target_env=fx.get("deployment_environment", "non-production"),
        abort_note="abort above the agentic tail (tool turns run heavier than chat turns)",
        risks_extra=[f"Tools observed: {split.get('tools_observed')}.",
                     "Behavioral split via engine.archetypes.classify_by_terminal "
                     "(terminal signal = execute_tool) — same engine as commerce (order-terminal)."],
    )
    return model, proposal


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="workload-model engine CLI")
    ap.add_argument("--extract", required=True, type=Path, help="neutral telemetry extract JSON")
    ap.add_argument("--out", required=True, type=Path, help="output directory")
    ap.add_argument("--mode", default="agentic", choices=["agentic", "commerce"])
    a = ap.parse_args(argv)
    return run(json.loads(a.extract.read_text()), a.out, a.mode)


if __name__ == "__main__":
    raise SystemExit(main())
