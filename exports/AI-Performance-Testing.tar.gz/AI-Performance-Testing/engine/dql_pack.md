# Validated DQL query pack (Dynatrace / dtctl)

The backend-specific **input adapter** for the workload-model engine. These queries extract the
neutral facts the engine consumes (entry journeys, service sets, per-journey baselines, arrival
curve, cache key cardinality). Field names were confirmed live on tenant **oat05854**.

Conventions: `duration` is **ns**; `start_time`/`end_time` are the usable span timestamps
(`timestamp` is empty on spans); `request.is_root_span == true` is validated (`isEntrySpan()` is
illustrative only). Grail snaps `makeTimeseries`/`bin` interval upward over long windows
(~1000-bucket cap) — read the returned interval, and trim partial boundary bins before CoV
(`engine.shaping.trim_partial_bins`).

### Access-log availability probe (run FIRST — drives the G0 spans-only caveat)
```dql
fetch logs, from: -2h | filter k8s.container.name == "istio-proxy" | summarize lines = count()
```
`lines > 0` → enumerate the edge HTTP surface by `{authority, method, path, response_code}` and
chain by `request_id`. `lines == 0` → access logs unavailable: record the spans-only caveat and
recover the HTTP surface from server-span `span.name` routes.

### G1-C — front-end discovery (earliest-start root per trace)
```dql
fetch spans, from: -2h
| filter request.is_root_span == true
| sort start_time asc
| summarize entryService = takeFirst(service.name), entryOp = takeFirst(span.name), by: { trace.id }
| summarize traces = count(), by: { entryService, entryOp }
| sort traces desc
```
Noise classifier drops: `GET /health|/healthz|/livez|/readyz`, `GET /metrics`, `flagd *`,
`span.kind == "consumer"`. Keep the external originator (`user_*` driver) or the edge server.

### G1-E — per-journey reach + service set (archetype/cluster input)
```dql
fetch spans, from: -1h
| filter request.is_root_span == true and service.name == $entry and startsWith(span.name, "user_")
| fields trace.id, entryOp = span.name
| join [ fetch spans, from: -1h | summarize services = collectDistinct(service.name), by: { trace.id } ],
       kind: inner, on: { trace.id }, fields: { services }
| summarize traces = count(), svcSet = takeAny(services), by: { entryOp }
| sort traces desc
```

### Journey step reconstruction (ordered flow from the trace span-tree)
```dql
fetch spans, from: -3h | filter <entry trace ids>
| join [ fetch spans | sort start_time asc
         | summarize steps = collectArray(concat(service.name, " ", span.name)), by: { trace.id } ],
       kind: inner, on: { trace.id }, fields: { steps }
```

### Server-span baseline + Little's Law inputs (NOT the load-driver wrapper)
```dql
fetch spans, from: -3h
| filter span.kind == "server" and service.name == $frontendServer
| summarize p50 = percentile(duration,50)/1000000.0, p95 = percentile(duration,95)/1000000.0,
            p99 = percentile(duration,99)/1000000.0, mean = avg(duration)/1000000.0, by: { span.name }
```
Observed concurrency (busy-time integral): `summarize sum(duration)` ÷ window_ns.

### G3-B — per-minute arrival curve (CoV → steady/ramp)
```dql
fetch spans, from: -3h | filter request.is_root_span == true and service.name == $entry
| summarize c = count(), by: { min = bin(start_time, 1m) }
```

### G4 — cache key cardinality
```dql
fetch spans, from: -3h | filter service.name == $cacheService and isNotNull($keyAttr)
| summarize keys = countDistinctExact($keyAttr), reads = count()
```

**Agentic apps:** the same pack applies; the terminal-action signal is `execute_tool` presence
(`engine.archetypes.AGENTIC_TOOL_PATTERNS`) instead of order-terminal services, yielding
Agentic (tool-using) vs Conversational (pure-LLM) turn archetypes.
