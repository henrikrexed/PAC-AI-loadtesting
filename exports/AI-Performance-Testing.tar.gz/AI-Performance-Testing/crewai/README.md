# CrewAI crew — workload-model (SCOPE)

```bash
pip install -r requirements.txt            # crewai
# deterministic engine pipeline (no LLM needed):
python workload_model_crew.py --no-llm --extract ../examples/crewai-deepseek-agent/extract.json --out ./out
# full agent crew (needs an LLM, e.g. OPENAI_API_KEY or DeepSeek via LiteLLM):
python workload_model_crew.py --extract ../examples/crewai-deepseek-agent/extract.json --out ./out
```
The crew's `build_workload_model` tool calls the shared `engine/` (archetype split → load/ramp →
G0) and refuses to return a model that fails G0. The `extract_telemetry` tool is the adapter seam
— swap its body for a live dtctl/DQL adapter. See the repo README for the full picture.
