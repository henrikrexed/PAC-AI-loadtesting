"""CrewAI packaging of the workload-model (SCOPE) skill.

A single-agent crew that turns a neutral telemetry extract into a validated workload model +
scenario proposal, gated by G0. The heavy lifting lives in the shared `engine/` package (the
same code the Claude skill and Goose recipe use) — CrewAI only orchestrates.

Two tools:
  * `ExtractTelemetryTool` — adapter seam. Replace its body with your backend's extraction
    (the dtctl/DQL pack in ../engine/dql_pack.md). The reference impl loads a pre-captured
    neutral extract JSON so the crew runs offline/deterministically.
  * `BuildWorkloadModelTool` — calls the engine (front-end discovery → archetype split →
    load/ramp shaping → emit → G0). Refuses to return a model unless G0 passes.

Run:  python workload_model_crew.py --extract ../examples/crewai-deepseek-agent/extract.json
Requires an LLM for the CrewAI agent (set OPENAI_API_KEY / DeepSeek via LiteLLM). The engine
tools themselves need no LLM, so `--no-llm` runs the deterministic pipeline directly.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent / "engine"
sys.path.insert(0, str(ENGINE))

from cli import run as engine_run  # noqa: E402  (shared engine entry point)


def build_model_from_extract(extract_path: str, out_dir: str, mode: str = "agentic") -> dict:
    """Deterministic core: neutral extract -> workload-model.json + proposal, G0-gated."""
    extract = json.loads(Path(extract_path).read_text())
    code = engine_run(extract, Path(out_dir), mode)
    return {"g0_passed": code == 0, "out_dir": out_dir,
            "model": str(Path(out_dir) / "workload-model.json")}


def _build_crew(extract_path: str, out_dir: str, mode: str):
    """Construct the CrewAI crew. Imported lazily so --no-llm works without crewai installed."""
    from crewai import Agent, Task, Crew, Process
    from crewai.tools import tool

    @tool("extract_telemetry")
    def extract_telemetry() -> str:
        """Adapter seam: return the neutral telemetry extract (JSON string).
        Reference impl loads a pre-captured extract; swap for a live dtctl/DQL adapter."""
        return Path(extract_path).read_text()

    @tool("build_workload_model")
    def build_workload_model(_extract_json: str = "") -> str:
        """Run the workload-model engine (archetype split + load/ramp + G0). Returns the G0 result."""
        res = build_model_from_extract(extract_path, out_dir, mode)
        return json.dumps(res)

    modeler = Agent(
        role="Workload Modeler (SCOPE stage)",
        goal="Produce a schema-valid, G0-gated workload model from production telemetry, with "
             "1-6 behavioral scenarios, load + ramp, and honest risk caveats.",
        backstory="An SRE who turns observability data into realistic, reviewable load-test "
                  "scenarios. Never invents numbers; refuses to emit a model that fails G0.",
        tools=[extract_telemetry, build_workload_model],
        verbose=True,
    )
    task = Task(
        description="1) Call extract_telemetry to get the neutral facts. 2) Call "
                    "build_workload_model to run the engine and the G0 gate. 3) Summarize the "
                    "scenarios, weights, arrival shape, and the G0 verdict. Do not present a model "
                    "that failed G0.",
        expected_output="A short summary: scenarios + weights, arrival shape, Little's Law ratio, "
                        "and G0 pass/fail with the per-criterion breakdown.",
        agent=modeler,
    )
    return Crew(agents=[modeler], tasks=[task], process=Process.sequential, verbose=True)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="CrewAI workload-model crew")
    ap.add_argument("--extract", default="../examples/crewai-deepseek-agent/extract.json")
    ap.add_argument("--out", default="./out")
    ap.add_argument("--mode", default="agentic", choices=["agentic", "commerce"])
    ap.add_argument("--no-llm", action="store_true",
                    help="run the deterministic engine pipeline without the CrewAI LLM agent")
    a = ap.parse_args(argv)

    if a.no_llm:
        res = build_model_from_extract(a.extract, a.out, a.mode)
        print(json.dumps(res, indent=2))
        return 0 if res["g0_passed"] else 1

    crew = _build_crew(a.extract, a.out, a.mode)
    print(crew.kickoff())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
